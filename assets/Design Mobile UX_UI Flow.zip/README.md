
  # Design Mobile UX/UI Flow

  This is a code bundle for Design Mobile UX/UI Flow. The original project is available at https://www.figma.com/design/eV0OJlFF9bNoFUKG5pGVvy/Design-Mobile-UX-UI-Flow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  